package vn.edu.usth.mobilemid.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import vn.edu.usth.mobilemid.PrimeActivity;
import vn.edu.usth.mobilemid.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import vn.edu.usth.mobilemid.api.ApiClient;
import vn.edu.usth.mobilemid.api.GitHubService;
import vn.edu.usth.mobilemid.api.model.GitHubUser;

public class LoginFragment extends Fragment {

    private EditText usernameEditText;
    private Button loginButton;
    private ProgressBar loadingProgressBar;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_login, container, false);

        usernameEditText = rootView.findViewById(R.id.username);
        loginButton = rootView.findViewById(R.id.login);
        loadingProgressBar = rootView.findViewById(R.id.loading);

        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            if (username.isEmpty()) {
                Toast.makeText(getActivity(), "Please enter a username", Toast.LENGTH_SHORT).show();
                return;
            }

            authenticateUser(username);
        });

        return rootView;
    }

    private void authenticateUser(String username) {
        loadingProgressBar.setVisibility(View.VISIBLE);

        GitHubService service = ApiClient.getGitHubService();
        service.getUserByUsername(username).enqueue(new Callback<GitHubUser>() {
            @Override
            public void onResponse(Call<GitHubUser> call, Response<GitHubUser> response) {
                loadingProgressBar.setVisibility(View.GONE);
                if (response.isSuccessful()) {
                    GitHubUser user = response.body();
                    if (user != null) {
                        navigateToProfile(user);
                    } else {
                        showError("No user found.");
                    }
                } else {
                    showError("Invalid username or user not found.");
                }
            }

            @Override
            public void onFailure(Call<GitHubUser> call, Throwable t) {
                loadingProgressBar.setVisibility(View.GONE);
                showError("Error: " + t.getMessage());
            }
        });
    }

    private void navigateToProfile(GitHubUser user) {
        Toast.makeText(getActivity(), "Welcome, " + user.getLogin(), Toast.LENGTH_SHORT).show();

        if (getActivity() != null) {
            PrimeActivity mainActivity = (PrimeActivity) getActivity();
            mainActivity.showBottomNavigation();
            mainActivity.loadFragment(new HomeFragment(), true);
        }
    }

    private void showError(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }

    private void loadFragment(Fragment fragment) {
        if (getActivity() instanceof PrimeActivity) {
            ((PrimeActivity) getActivity()).loadFragment(fragment, true);
        }
    }
}
