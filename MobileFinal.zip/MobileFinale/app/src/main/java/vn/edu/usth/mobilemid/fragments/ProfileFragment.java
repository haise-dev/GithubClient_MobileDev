package vn.edu.usth.mobilemid.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

import vn.edu.usth.mobilemid.PrimeActivity;
import vn.edu.usth.mobilemid.R;
import vn.edu.usth.mobilemid.adapters.AdapterForProfileDrag;
import vn.edu.usth.mobilemid.items.ProfileItem;

public class ProfileFragment extends Fragment implements AdapterForProfileDrag.OnItemClickListener {
    private RecyclerView recyclerView;
    private AdapterForProfileDrag recyclerAdapter;
    private List<ProfileItem> profileItemsList;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    public ProfileFragment() {
    }

    public static ProfileFragment newInstance(String param1, String param2) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Initialize list
        profileItemsList = new ArrayList<>();
        profileItemsList.add(new ProfileItem("Repositories", R.drawable.repositories, 10));
        profileItemsList.add(new ProfileItem("Starred", R.drawable.starred, 0));
        profileItemsList.add(new ProfileItem("Organizations", R.drawable.organizations, 0));
        if (getArguments() != null) {
            String mParam1 = getArguments().getString(ARG_PARAM1);
            String mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        recyclerView = view.findViewById(R.id.profileRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        recyclerAdapter = new AdapterForProfileDrag(profileItemsList);
        recyclerAdapter.setOnItemClickListener(this);
        recyclerView.setAdapter(recyclerAdapter);

        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP | ItemTouchHelper.DOWN, 0) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                int fromPosition = viewHolder.getAdapterPosition();
                int toPosition = target.getAdapterPosition();

                ProfileItem movedItem = profileItemsList.remove(fromPosition);
                profileItemsList.add(toPosition, movedItem);

                recyclerAdapter.notifyItemMoved(fromPosition, toPosition);
                return true;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            }
        };

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);

        ImageView go_statusLayout = view.findViewById(R.id.open_status);
        LinearLayout go_popularLayout = view.findViewById(R.id.profile_popular);

        go_statusLayout.setOnClickListener(v -> {
            loadFragment(new ProfileStatusFragment());
        });

        go_popularLayout.setOnClickListener(v -> {
            loadFragment(new ProfilePopularFragment());
        });

        return view;
    }

    @Override
    public void onItemClick(int position) {
        ProfileItem clickedItem = profileItemsList.get(position);
        String itemName = clickedItem.getTitle();

        switch (itemName) {
            case "Repositories":
                loadFragment(new HomeRepositoriesFragment());
                break;
            case "Starred":
                loadFragment(new ProfileStarredFragment());
                break;
            case "Organizations":
                loadFragment(new ProfileOrganizationsFragment());
                break;
        }
    }

    private void loadFragment(Fragment fragment) {
        if (getActivity() instanceof PrimeActivity) {
            ((PrimeActivity) getActivity()).loadFragment(fragment, false);
        }
    }
}
