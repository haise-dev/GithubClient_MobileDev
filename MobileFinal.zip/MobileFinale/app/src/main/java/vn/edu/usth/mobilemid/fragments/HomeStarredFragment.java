package vn.edu.usth.mobilemid.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import vn.edu.usth.mobilemid.PrimeActivity;
import vn.edu.usth.mobilemid.R;

public class HomeStarredFragment extends Fragment {
    private TextView go_homeLayout;
    private TextView go_explore;

    public HomeStarredFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home_starred, container, false);

        go_homeLayout = view.findViewById(R.id.back_button);
        go_explore = view.findViewById(R.id.exploreButton);

        go_homeLayout.setOnClickListener(v -> switchToFragment(new HomeFragment()));
        go_explore.setOnClickListener(v -> switchToFragment(new ExploreFragment()));

        return view;
    }

    private void switchToFragment(Fragment fragment) {
        if (getActivity() instanceof PrimeActivity) {
            ((PrimeActivity) getActivity()).loadFragment(fragment, false);
        }
    }
}
