package vn.edu.usth.mobilemid.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import vn.edu.usth.mobilemid.PrimeActivity;
import vn.edu.usth.mobilemid.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeProjectFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeProjectFragment extends Fragment {
    private TextView go_homeLayout;

    // Parameters for fragment initialization (optional, used for passing data to fragment)
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;

    public HomeProjectFragment() {
        // Required empty public constructor
    }

    /**
     * Factory method to create a new instance of HomeProjectFragment.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeProjectFragment.
     */
    public static HomeProjectFragment newInstance(String param1, String param2) {
        HomeProjectFragment fragment = new HomeProjectFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home_project, container, false);

        go_homeLayout = view.findViewById(R.id.back_button);
        go_homeLayout.setOnClickListener(v -> loadFragment(new HomeFragment()));

        return view;
    }

    private void loadFragment(Fragment fragment) {
        if (getActivity() instanceof PrimeActivity) {
            ((PrimeActivity) getActivity()).loadFragment(fragment, false);
        }
    }
}
