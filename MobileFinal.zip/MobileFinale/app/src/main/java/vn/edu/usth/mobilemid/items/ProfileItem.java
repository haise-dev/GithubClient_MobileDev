package vn.edu.usth.mobilemid.items;

public class ProfileItem {
    private String title;
    private int iconResId;
    private int count;

    public ProfileItem(String title, int iconResId, int count) {
        this.title = title;
        this.iconResId = iconResId;
        this.count = count;
    }

    public String getTitle() {
        return title;
    }

    public int getIconResId() {
        return iconResId;
    }

    public int getCount() {
        return count;
    }
}
