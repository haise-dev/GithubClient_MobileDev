package vn.edu.usth.mobilemid.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import vn.edu.usth.mobilemid.R;

public class MergedFragment extends Fragment {

    public MergedFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_merged, container, false);

        FragmentManager fragmentManager = getChildFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        HomeFragment homeFragment = new HomeFragment();
        NotificationFragment notificationFragment = new NotificationFragment();
        ExploreFragment exploreFragment = new ExploreFragment();
        ProfileFragment profileFragment = new ProfileFragment();

        fragmentTransaction.replace(R.id.fragment_home_container, homeFragment);
        fragmentTransaction.replace(R.id.fragment_notification_container, notificationFragment);
        fragmentTransaction.replace(R.id.fragment_explore_container, exploreFragment);
        fragmentTransaction.replace(R.id.fragment_profile_container, profileFragment);

        fragmentTransaction.commit();

        return view;
    }
}
