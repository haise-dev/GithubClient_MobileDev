package vn.edu.usth.mobilemid.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import vn.edu.usth.mobilemid.api.ApiClient;
import vn.edu.usth.mobilemid.api.GitHubService;
import vn.edu.usth.mobilemid.models.FileContent;

import android.util.Base64;

public class FileContentViewModel extends ViewModel {

    private MutableLiveData<String> fileContent = new MutableLiveData<>();

    public LiveData<String> getFileContent() {
        return fileContent;
    }

    public void loadFileContent(String owner, String repoName, String path) {
        GitHubService service = ApiClient.getGitHubService();
        Call<FileContent> call = service.getFileContent(owner, repoName, path);
        call.enqueue(new Callback<FileContent>() {
            @Override
            public void onResponse(Call<FileContent> call, Response<FileContent> response) {
                if (response.isSuccessful() && response.body() != null) {
                    String content = response.body().getContent();
                    String decodedContent = new String(Base64.decode(content, Base64.DEFAULT));
                    fileContent.setValue(decodedContent);
                }
            }

            @Override
            public void onFailure(Call<FileContent> call, Throwable t) {
                fileContent.setValue("Failed to load content.");
            }
        });
    }
}
