package vn.edu.usth.mobilemid.models;

import com.google.gson.annotations.SerializedName;

public class FileUploadRequest {

    @SerializedName("message")
    private String message;

    @SerializedName("content")
    private String content; // Base64-encoded file content

    @SerializedName("sha")
    private String sha; // Optional, only needed if updating an existing file

    public FileUploadRequest(String message, String content, String sha) {
        this.message = message;
        this.content = content;
        this.sha = sha;
    }

    public FileUploadRequest(String message, String content) {
        this(message, content, null);
    }
}
