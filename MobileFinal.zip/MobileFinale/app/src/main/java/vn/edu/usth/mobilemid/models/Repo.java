package vn.edu.usth.mobilemid.models;

import com.google.gson.annotations.SerializedName;

public class Repo {

    @SerializedName("name")
    private String name;

    @SerializedName("owner")
    private Owner owner;

    // Constructor, getters, and other fields

    public Repo(String name, Owner owner) {
        this.name = name;
        this.owner = owner;
    }

    public String getName() {
        return name;
    }

    public Owner getOwner() {
        return owner;
    }

    public static class Owner {
        @SerializedName("login")
        private String login;

        public Owner(String login) {
            this.login = login;
        }

        public String getLogin() {
            return login;
        }
    }
}
