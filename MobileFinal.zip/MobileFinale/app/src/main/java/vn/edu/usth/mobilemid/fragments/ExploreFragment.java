package vn.edu.usth.mobilemid.fragments;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

import vn.edu.usth.mobilemid.R;
import vn.edu.usth.mobilemid.adapters.AdapterforExploredrag;
import vn.edu.usth.mobilemid.items.ExploreItem;
import vn.edu.usth.mobilemid.PrimeActivity;

public class ExploreFragment extends Fragment implements AdapterforExploredrag.OnItemClickListener {

    private RecyclerView recyclerView;
    private AdapterforExploredrag recyclerAdapter;
    private List<ExploreItem> exploreItemsList;

    public ExploreFragment() {
    }

    public static ExploreFragment newInstance(String param1, String param2) {
        ExploreFragment fragment = new ExploreFragment();
        Bundle args = new Bundle();
        args.putString("param1", param1);
        args.putString("param2", param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        exploreItemsList = new ArrayList<>();
        exploreItemsList.add(new ExploreItem("Trending Repositories", R.drawable.ic_trending));
        exploreItemsList.add(new ExploreItem("Awesome Lists", R.drawable.ic_awesome_lists));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_explore, container, false);

        recyclerView = view.findViewById(R.id.exploreRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        recyclerAdapter = new AdapterforExploredrag(exploreItemsList);
        recyclerAdapter.setOnItemClickListener(this);
        recyclerView.setAdapter(recyclerAdapter);

        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP | ItemTouchHelper.DOWN, 0) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                int fromPosition = viewHolder.getAdapterPosition();
                int toPosition = target.getAdapterPosition();

                ExploreItem movedItem = exploreItemsList.remove(fromPosition);
                exploreItemsList.add(toPosition, movedItem);

                recyclerAdapter.notifyItemMoved(fromPosition, toPosition);
                return true;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            }
        };

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);

        return view;
    }

    @Override
    public void onItemClick(int position) {
        ExploreItem clickedItem = exploreItemsList.get(position);
        String itemName = clickedItem.getTitle();

        switch (itemName) {
            case "Trending Repositories":
                loadFragment(new ExploreTrendingRepFragment());
                break;
            case "Awesome Lists":
                loadFragment(new ExploreAwesomeFragment());
                break;
        }
    }

    private void loadFragment(Fragment fragment) {
        if (getActivity() instanceof PrimeActivity) {
            ((PrimeActivity) getActivity()).loadFragment(fragment, false);
        }
    }
}
