package vn.edu.usth.mobilemid.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import vn.edu.usth.mobilemid.api.ApiClient;
import vn.edu.usth.mobilemid.api.GitHubService;
import vn.edu.usth.mobilemid.models.RepoFile;

import java.util.List;

public class RepositoryDetailViewModel extends ViewModel {

    private MutableLiveData<List<RepoFile>> repoFiles = new MutableLiveData<>();

    public LiveData<List<RepoFile>> getRepoFiles() {
        return repoFiles;
    }

    public void loadRepoFiles(String owner, String repoName) {
        GitHubService service = ApiClient.getGitHubService();
        Call<List<RepoFile>> call = service.getRepoFiles(owner, repoName);
        call.enqueue(new Callback<List<RepoFile>>() {
            @Override
            public void onResponse(Call<List<RepoFile>> call, Response<List<RepoFile>> response) {
                if (response.isSuccessful()) {
                    repoFiles.setValue(response.body());
                }
            }

            @Override
            public void onFailure(Call<List<RepoFile>> call, Throwable t) {
                // Xử lý lỗi
            }
        });
    }
}
