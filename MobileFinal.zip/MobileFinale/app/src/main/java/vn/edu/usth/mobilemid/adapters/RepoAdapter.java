package vn.edu.usth.mobilemid.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

import vn.edu.usth.mobilemid.R;
import vn.edu.usth.mobilemid.models.Repo;

public class RepoAdapter extends RecyclerView.Adapter<RepoAdapter.RepoViewHolder> {

    private List<Repo> repos = new ArrayList<>();
    private OnRepoClickListener repoClickListener;
    private OnPushClickListener pushClickListener;

    // Listener interface for repository item clicks
    public interface OnRepoClickListener {
        void onRepoClick(Repo repo);
    }

    // Listener interface for "Push" button clicks
    public interface OnPushClickListener {
        void onPushClick(Repo repo);
    }

    public RepoAdapter(OnRepoClickListener repoClickListener, OnPushClickListener pushClickListener) {
        this.repoClickListener = repoClickListener;
        this.pushClickListener = pushClickListener; // Correctly set pushClickListener here
    }

    @NonNull
    @Override
    public RepoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_repo, parent, false);
        return new RepoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RepoViewHolder holder, int position) {
        Repo repo = repos.get(position);
        holder.repoNameTextView.setText(repo.getName());

        // Set click listener for repository item
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (repoClickListener != null) {
                    repoClickListener.onRepoClick(repo); // Trigger repo item click listener
                }
            }
        });

        // Set click listener for the "Push" button
        holder.pushButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pushClickListener != null) {
                    pushClickListener.onPushClick(repo); // Trigger push button click listener
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return repos.size();
    }

    public void setRepos(List<Repo> repos) {
        this.repos = repos;
        notifyDataSetChanged();
    }

    static class RepoViewHolder extends RecyclerView.ViewHolder {
        TextView repoNameTextView;
        Button pushButton;

        RepoViewHolder(@NonNull View itemView) {
            super(itemView);
            repoNameTextView = itemView.findViewById(R.id.repo_name_text_view);
            pushButton = itemView.findViewById(R.id.push_button);
        }
    }
}
