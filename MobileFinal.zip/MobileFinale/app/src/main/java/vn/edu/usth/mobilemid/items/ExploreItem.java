package vn.edu.usth.mobilemid.items;

public class ExploreItem {
    private String title;
    private int iconResId;

    public ExploreItem(String title, int iconResId) {
        this.title = title;
        this.iconResId = iconResId;
    }

    public String getTitle() {
        return title;
    }

    public int getIconResId() {
        return iconResId;
    }
}
