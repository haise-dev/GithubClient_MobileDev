package vn.edu.usth.mobilemid.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.List;

import vn.edu.usth.mobilemid.R;
import vn.edu.usth.mobilemid.models.WorkflowRun;

public class WorkflowAdapter extends RecyclerView.Adapter<WorkflowAdapter.WorkflowViewHolder> {

    private List<WorkflowRun> workflows = new ArrayList<>();

    @NonNull
    @Override
    public WorkflowViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_workflow, parent, false);
        return new WorkflowViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WorkflowViewHolder holder, int position) {
        WorkflowRun workflow = workflows.get(position);
        holder.workflowNameTextView.setText(workflow.getName());
        holder.workflowStatusTextView.setText(workflow.getStatus());
    }

    @Override
    public int getItemCount() {
        return workflows.size();
    }

    public void setWorkflows(List<WorkflowRun> workflows) {
        this.workflows = workflows;
        notifyDataSetChanged();
    }

    static class WorkflowViewHolder extends RecyclerView.ViewHolder {
        TextView workflowNameTextView;
        TextView workflowStatusTextView;

        WorkflowViewHolder(@NonNull View itemView) {
            super(itemView);
            workflowNameTextView = itemView.findViewById(R.id.workflow_name_text_view);
            workflowStatusTextView = itemView.findViewById(R.id.workflow_status_text_view);
        }
    }
}
