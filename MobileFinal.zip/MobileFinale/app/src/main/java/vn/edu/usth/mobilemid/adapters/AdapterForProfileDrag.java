package vn.edu.usth.mobilemid.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import vn.edu.usth.mobilemid.R;
import vn.edu.usth.mobilemid.items.ProfileItem;

public class AdapterForProfileDrag extends RecyclerView.Adapter<AdapterForProfileDrag.ViewHolder> {
    private List<ProfileItem> profileItemsList;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public AdapterForProfileDrag(List<ProfileItem> profileItemsList) {
        this.profileItemsList = profileItemsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_layout_for_profile, parent, false);
        return new ViewHolder(view, mListener);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ProfileItem item = profileItemsList.get(position);
        holder.imageView.setImageResource(item.getIconResId());
        holder.textView.setText(item.getTitle());
        holder.countView.setText(String.valueOf(item.getCount()));
    }

    @Override
    public int getItemCount() {
        return profileItemsList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;//icon
        TextView textView;//title
        TextView countView;

        public ViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            imageView = itemView.findViewById(R.id.icon);
            textView = itemView.findViewById(R.id.title);
            countView = itemView.findViewById(R.id.count);

            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(position);
                    }
                }
            });
        }
    }
}
