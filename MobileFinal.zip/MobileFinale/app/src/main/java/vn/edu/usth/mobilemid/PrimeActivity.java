package vn.edu.usth.mobilemid;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import vn.edu.usth.mobilemid.fragments.ExploreFragment;
import vn.edu.usth.mobilemid.fragments.HomeFragment;
import vn.edu.usth.mobilemid.fragments.LoginFragment;
import vn.edu.usth.mobilemid.fragments.NotificationFragment;
import vn.edu.usth.mobilemid.fragments.RepoFragment;
import vn.edu.usth.mobilemid.fragments.RepositoryDetailFragment;
import vn.edu.usth.mobilemid.fragments.ProfileFragment;

public class PrimeActivity extends AppCompatActivity implements RepoFragment.OnRepoSelectedListener {

    private DrawerLayout drawerLayout;
    private FragmentContainerView fragmentContainer;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prime);

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setVisibility(View.GONE);
        loadFragment(new LoginFragment(),true);
        // Initialize fragment container
        fragmentContainer = findViewById(R.id.fragment_container);
        // Set up the drawer and navigation view
        //NavigationView navigationView = findViewById(R.id.navigation_view);
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Set the Navigation Item Click Listener
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            Fragment fragment = null;
            boolean addToBackStack = true;  // Default behavior: add to back stack

            if (item.getItemId() == R.id.nav_home) {
                fragment = new HomeFragment();
            } else if (item.getItemId() == R.id.nav_noti) {
                fragment = new NotificationFragment();
            } else if (item.getItemId() == R.id.nav_explore) {
                fragment = new ExploreFragment();
            } else if (item.getItemId() == R.id.nav_profile) {
                fragment = new ProfileFragment();
            } else {
                return false;
            }

            // If ProfileFragment is selected and already visible, don't add it to the back stack
            if (fragment instanceof ProfileFragment) {
                Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
                if (currentFragment instanceof ProfileFragment) {
                    addToBackStack = false;  // Don't add ProfileFragment to the back stack if it's already displayed
                }
            }

            if (fragment != null) {
                loadFragment(fragment, addToBackStack);
            }

            drawerLayout.closeDrawers(); // Close the drawer after selection
            return true;
        });
    }

    @Override
    public void onRepoSelected(String owner, String repoName) {
        RepositoryDetailFragment fragment = RepositoryDetailFragment.newInstance(owner, repoName);
        loadFragment(fragment, true); // Always add RepoDetailFragment to back stack
    }

    public void loadFragment(Fragment fragment, boolean addToBackStack) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, fragment); // Replace the container view with the new fragment

        if (addToBackStack) {
            fragmentTransaction.addToBackStack(null); // Add to back stack if the condition is true
        }

        fragmentTransaction.commit();
    }

    // Method to switch to a fragment from RepoFragment or elsewhere
    public void switchToFragment(int position) {
        Log.d("Prime", "Fragment placement" + position);
        // Use this method to directly switch fragments if needed, depending on position or item clicked.
    }

    private void showFragmentContainerView() {
        fragmentContainer.setVisibility(View.VISIBLE);
    }

    private void showViewPager2() {
        fragmentContainer.setVisibility(View.GONE);
    }

    public void showBottomNavigation() {
        bottomNavigationView.setVisibility(View.VISIBLE);
    }
}
