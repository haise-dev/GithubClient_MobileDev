package vn.edu.usth.mobilemid.api.model;

public class GitHubEmail {
    private String email;
    private boolean primary;
    private boolean verified;
    private boolean visibility;

    // Getters
    public String getEmail() {
        return email;
    }

    public boolean isPrimary() {
        return primary;
    }

    public boolean isVerified() {
        return verified;
    }

    public boolean isVisible() {
        return visibility;
    }
}
