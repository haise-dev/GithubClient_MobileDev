package vn.edu.usth.mobilemid.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import vn.edu.usth.mobilemid.adapters.AdapterforHomedrag;
import vn.edu.usth.mobilemid.items.HomeItem;
import vn.edu.usth.mobilemid.PrimeActivity;
import vn.edu.usth.mobilemid.R;

public class HomeFragment extends Fragment implements AdapterforHomedrag.OnItemClickListener {
    private RecyclerView recyclerView;
    private AdapterforHomedrag recyclerAdapter;
    private List<HomeItem> itemsList;

    public HomeFragment() {
    }

    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString("param1", param1);
        args.putString("param2", param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        itemsList = new ArrayList<>();
        itemsList.add(new HomeItem("Issues", R.drawable.issue));
        itemsList.add(new HomeItem("Pull Request", R.drawable.pull));
        itemsList.add(new HomeItem("Discussions", R.drawable.discussion));
        itemsList.add(new HomeItem("Project", R.drawable.project));
        itemsList.add(new HomeItem("Repositories", R.drawable.repo));
        itemsList.add(new HomeItem("Organizations", R.drawable.org));
        itemsList.add(new HomeItem("Starred", R.drawable.star));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        recyclerAdapter = new AdapterforHomedrag(itemsList);
        recyclerAdapter.setOnItemClickListener(this);
        recyclerView.setAdapter(recyclerAdapter);

        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP | ItemTouchHelper.DOWN, 0) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                int fromPosition = viewHolder.getBindingAdapterPosition();
                int toPosition = target.getBindingAdapterPosition();

                HomeItem movedItem = itemsList.remove(fromPosition);
                itemsList.add(toPosition, movedItem);

                recyclerAdapter.notifyItemMoved(fromPosition, toPosition);
                return true;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            }
        };

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);

        View addFavoritesButton = view.findViewById(R.id.go_to_home_fav);
        View getStartedButton = view.findViewById(R.id.go_to_home_shortcuts);

        addFavoritesButton.setOnClickListener(v -> loadFragment(new HomeFavoritesFragment()));
        getStartedButton.setOnClickListener(v -> loadFragment(new HomeShortcutsFragment()));

        return view;
    }

    @Override
    public void onItemClick(int position) {
        HomeItem clickedItem = itemsList.get(position);
        String itemName = clickedItem.getTitle();

        switch (itemName) {
            case "Issues":
                loadFragment(new HomeIssuesFragment());
                break;
            case "Pull Request":
                loadFragment(new HomePullRequestFragment());
                break;
            case "Discussions":
                loadFragment(new HomeDiscussionsFragment());
                break;
            case "Project":
                loadFragment(new HomeProjectFragment());
                break;
            case "Repositories":
                loadFragment(new HomeRepositoriesFragment());
                break;
            case "Organizations":
                loadFragment(new HomeOrganizationsFragment());
                break;
            case "Starred":
                loadFragment(new HomeStarredFragment());
                break;
        }
    }

    private void loadFragment(Fragment fragment) {
        if (getActivity() instanceof PrimeActivity) {
            ((PrimeActivity) getActivity()).loadFragment(fragment, true);
        }
    }
}
