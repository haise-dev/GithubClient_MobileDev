package vn.edu.usth.mobilemid.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import vn.edu.usth.mobilemid.R;
import vn.edu.usth.mobilemid.adapters.RepoAdapter;
import vn.edu.usth.mobilemid.api.ApiClient;
import vn.edu.usth.mobilemid.api.GitHubService;
import vn.edu.usth.mobilemid.models.FileUpdateResponse;
import vn.edu.usth.mobilemid.models.FileUploadRequest;
import vn.edu.usth.mobilemid.models.Repo;
import vn.edu.usth.mobilemid.viewmodel.RepoViewModel;
import vn.edu.usth.mobilemid.PrimeActivity;
import android.database.Cursor;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class RepoFragment extends Fragment implements RepoAdapter.OnPushClickListener {

    private OnRepoSelectedListener callback;
    private RecyclerView recyclerView;
    private RepoAdapter adapter;
    private RepoViewModel repoViewModel;
    private String selectedRepoOwner;
    private String selectedRepoName;
    private ViewPager2 viewPager2;

    // Declare ActivityResultLauncher for the file picker
    private final ActivityResultLauncher<Intent> filePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Uri fileUri = result.getData().getData();
                    if (fileUri != null) {
                        try {
                            String fileName = getFileName(fileUri);
                            String fileContent = readFileContent(fileUri);

                            String commitMessage = "Add " + fileName;
                            uploadFileToRepo(selectedRepoOwner, selectedRepoName, fileName, fileContent, commitMessage);

                        } catch (IOException e) {
                            Toast.makeText(getContext(), "Failed to read file content", Toast.LENGTH_SHORT).show();
                            Log.e("RepoFragment", "File read error: ", e);
                        }
                    }
                }
            }
    );

    public interface OnRepoSelectedListener {
        void onRepoSelected(String owner, String repoName);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnRepoSelectedListener) {
            callback = (OnRepoSelectedListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnRepoSelectedListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_repos, container, false);

        recyclerView = view.findViewById(R.id.recycler_view_repos);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new RepoAdapter(new RepoAdapter.OnRepoClickListener() {
            @Override
            public void onRepoClick(Repo repo) {
                switchToRepoDetailFragment(repo.getOwner().getLogin(), repo.getName());
            }
        }, this);
        recyclerView.setAdapter(adapter);

        repoViewModel = new ViewModelProvider(this).get(RepoViewModel.class);
        repoViewModel.getRepos().observe(getViewLifecycleOwner(), new Observer<List<Repo>>() {
            @Override
            public void onChanged(List<Repo> repos) {
                adapter.setRepos(repos);
            }
        });

        return view;
    }

    private void onRepositoryClicked(Repo repo) {
        if (callback != null) {
            callback.onRepoSelected(repo.getOwner().getLogin(), repo.getName());
        }
    }

    @Override
    public void onPushClick(Repo repo) {
        // Store the selected repo details
        selectedRepoOwner = repo.getOwner().getLogin();
        selectedRepoName = repo.getName();

        // Launch file picker using ActivityResultLauncher
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        filePickerLauncher.launch(intent);
    }

    private String readFileContent(Uri uri) throws IOException {
        try (InputStream inputStream = getContext().getContentResolver().openInputStream(uri)) {
            byte[] fileBytes = new byte[inputStream.available()];
            inputStream.read(fileBytes);
            return Base64.encodeToString(fileBytes, Base64.NO_WRAP);
        }
    }

    private String getFileName(Uri uri) {
        String fileName = "unknown";
        Cursor cursor = getContext().getContentResolver().query(uri, null, null, null, null);
        if (cursor != null) {
            int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            if (nameIndex >= 0 && cursor.moveToFirst()) {
                fileName = cursor.getString(nameIndex);
            }
            cursor.close();
        }
        return fileName;
    }

    private void uploadFileToRepo(String owner, String repo, String path, String content, String commitMessage) {
        GitHubService service = ApiClient.getGitHubService();
        FileUploadRequest request = new FileUploadRequest(commitMessage, content);

        service.uploadFile(owner, repo, path, request).enqueue(new Callback<FileUpdateResponse>() {
            @Override
            public void onResponse(Call<FileUpdateResponse> call, Response<FileUpdateResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(getContext(), "File pushed successfully to " + repo, Toast.LENGTH_SHORT).show();
                } else {
                    Log.e("RepoFragment", "Failed to push file: " + response.errorBody());
                    Toast.makeText(getContext(), "Failed to push file: " + response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<FileUpdateResponse> call, Throwable t) {
                Log.e("RepoFragment", "Push failed: " + t.getMessage(), t);
                Toast.makeText(getContext(), "Push failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDetach() {
        super.onDetach();
        callback = null;
    }

    private void switchToRepoDetailFragment(String owner, String repoName) {
        Log.d("RepoFragment", "Navigating to RepoDetailFragment");
        RepositoryDetailFragment repositoryDetailFragment = RepositoryDetailFragment.newInstance(owner, repoName);

        getParentFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, repositoryDetailFragment)
                .addToBackStack(null)
                .commit();
    }

    private void loadFragment(Fragment fragment) {
        if (getActivity() instanceof PrimeActivity) {
            ((PrimeActivity) getActivity()).loadFragment(fragment, true);
        }
    }
}
