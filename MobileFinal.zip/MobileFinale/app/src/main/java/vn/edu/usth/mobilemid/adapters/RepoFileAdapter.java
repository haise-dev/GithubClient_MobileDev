package vn.edu.usth.mobilemid.adapters;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import vn.edu.usth.mobilemid.models.RepoFile;
import java.util.ArrayList;
import java.util.List;

import vn.edu.usth.mobilemid.R;

public class RepoFileAdapter extends RecyclerView.Adapter<RepoFileAdapter.RepoFileViewHolder> {

    private List<RepoFile> repoFiles = new ArrayList<>();
    private final OnFileClickListener onFileClickListener;
    private final OnDownloadClickListener onDownloadClickListener;

    // Interface for regular file click (e.g., open file)
    public interface OnFileClickListener {
        void onFileClick(String filePath);
    }

    // Interface for download button click
    public interface OnDownloadClickListener {
        void onDownloadClick(RepoFile repoFile);
    }

    public RepoFileAdapter(OnFileClickListener fileClickListener, OnDownloadClickListener downloadClickListener) {
        this.onFileClickListener = fileClickListener;
        this.onDownloadClickListener = downloadClickListener;
    }

    @NonNull
    @Override
    public RepoFileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_repo_file, parent, false);
        return new RepoFileViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RepoFileViewHolder holder, int position) {
        RepoFile repoFile = repoFiles.get(position);
        holder.fileNameTextView.setText(repoFile.getName());

        // Set click listener for file name (open file)
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onFileClickListener != null) {
                    Log.d("RepoFileAdapter", "File clicked: " + repoFile.getPath());
                    onFileClickListener.onFileClick(repoFile.getPath());
                }
            }
        });

        // Set click listener for the download button
        holder.downloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onDownloadClickListener != null) {
                    Log.d("RepoFileAdapter", "Download button clicked for file: " + repoFile.getName());
                    onDownloadClickListener.onDownloadClick(repoFile);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return repoFiles.size();
    }

    public void setRepoFiles(List<RepoFile> files) {
        this.repoFiles = files;
        notifyDataSetChanged();
    }

    static class RepoFileViewHolder extends RecyclerView.ViewHolder {
        TextView fileNameTextView;
        Button downloadButton;

        RepoFileViewHolder(@NonNull View itemView) {
            super(itemView);
            fileNameTextView = itemView.findViewById(R.id.file_name_text_view);
            downloadButton = itemView.findViewById(R.id.download_button); // Ensure this ID matches in item_repo_file.xml
        }
    }
}
