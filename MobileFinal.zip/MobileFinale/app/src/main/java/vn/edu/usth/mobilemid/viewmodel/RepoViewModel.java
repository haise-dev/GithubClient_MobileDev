package vn.edu.usth.mobilemid.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import vn.edu.usth.mobilemid.api.GitHubService;
import vn.edu.usth.mobilemid.api.ApiClient;
import vn.edu.usth.mobilemid.models.Repo;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.util.Log;

public class RepoViewModel extends ViewModel {

    private final MutableLiveData<List<Repo>> repos = new MutableLiveData<>();
    private final MutableLiveData<String> errorMessage = new MutableLiveData<>();
    private final GitHubService gitHubService;

    public RepoViewModel() {
        gitHubService = ApiClient.getGitHubService();
        fetchRepos();
    }


    public LiveData<List<Repo>> getRepos() {
        return repos;
    }


    public LiveData<String> getErrorMessage() {
        return errorMessage;
    }

    private void fetchRepos() {
        gitHubService.getUserRepos().enqueue(new Callback<List<Repo>>() {
            @Override
            public void onResponse(Call<List<Repo>> call, Response<List<Repo>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    repos.setValue(response.body());
                } else {
                    errorMessage.setValue("Failed to load repos: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<List<Repo>> call, Throwable t) {
                Log.e("RepoViewModel", "API call failed", t);
                errorMessage.setValue("Error fetching repos: " + t.getMessage());
            }
        });
    }
}
