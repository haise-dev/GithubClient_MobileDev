package vn.edu.usth.mobilemid.api;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import vn.edu.usth.mobilemid.api.model.GitHubEmail;
import vn.edu.usth.mobilemid.api.model.GitHubFollower;
import vn.edu.usth.mobilemid.api.model.GitHubUser;
import vn.edu.usth.mobilemid.models.FileContent;
import vn.edu.usth.mobilemid.models.FileUpdateResponse;
import vn.edu.usth.mobilemid.models.FileUploadRequest;
import vn.edu.usth.mobilemid.models.Repo;
import vn.edu.usth.mobilemid.models.RepoFile;
import vn.edu.usth.mobilemid.models.WorkflowRun;



public interface GitHubService {

    // Endpoint để lấy danh sách các repo của người dùng
    @GET("user/repos")
    Call<List<Repo>> getUserRepos();

    // Endpoint để lấy danh sách các workflow runs cho một repo cụ thể
    @GET("repos/{owner}/{repo}/actions/runs")
    Call<List<WorkflowRun>> getWorkflowRuns(
            @Path("owner") String owner,
            @Path("repo") String repo
    );


    // Lấy danh sách file trong repository
    @GET("repos/{owner}/{repo}/contents")
    Call<List<RepoFile>> getRepoFiles(@Path("owner") String owner, @Path("repo") String repo);

    // Lấy nội dung file cụ thể
    @GET("repos/{owner}/{repo}/contents/{path}")
    Call<FileContent> getFileContent(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("path") String path
    );


    // Endpoint to create or update a file in a repository
    @PUT("repos/{owner}/{repo}/contents/{path}")
    Call<FileUpdateResponse> uploadFile(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("path") String path,
            @Body FileUploadRequest body
    );

    // Endpoint to fetch the authenticated user's profile details
    @GET("user")
    Call<GitHubUser> getUser();

    @GET("/users/{username}")
    Call<GitHubUser> getUserByUsername(@Path("username") String username);

    // Endpoint to fetch the user's primary email
    @GET("user/emails")
    Call<List<GitHubEmail>> getUserEmails();

    // Endpoint to fetch the user's followers
    @GET("user/followers")
    Call<List<GitHubFollower>> getUserFollowers();
}
