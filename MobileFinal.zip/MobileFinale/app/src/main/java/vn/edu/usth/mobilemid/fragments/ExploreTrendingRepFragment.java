package vn.edu.usth.mobilemid.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import vn.edu.usth.mobilemid.PrimeActivity;
import vn.edu.usth.mobilemid.R;

public class ExploreTrendingRepFragment extends Fragment {
    private TextView go_exploreLayout;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public ExploreTrendingRepFragment() {

    }

    public static ExploreTrendingRepFragment newInstance(String param1, String param2) {
        ExploreTrendingRepFragment fragment = new ExploreTrendingRepFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_explore_trending_rep, container, false);

        go_exploreLayout = view.findViewById(R.id.trending_back);
        go_exploreLayout.setOnClickListener(v -> loadFragment(new ExploreFragment()));

        return view;
    }

    private void loadFragment(Fragment fragment) {
        if (getActivity() instanceof PrimeActivity) {
            ((PrimeActivity) getActivity()).loadFragment(fragment, false);
        }
    }
}
